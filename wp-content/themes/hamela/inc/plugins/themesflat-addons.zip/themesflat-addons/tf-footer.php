        <?php do_action( 'tf_footer' ); ?>
    </div>
</div>
<?php wp_footer(); ?>
</body>
</html> 